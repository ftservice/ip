package com.mapbox.navigation.base.time.span

internal class TextSpanItem(override val span: Any, val spanText: String) : SpanItem
