package com.mapbox.navigation.base.time.span

internal interface SpanItem {
    val span: Any
}
